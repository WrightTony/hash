#include <iostream>
#include <sstream>
#include <ctime>
#include <random>
#include "HashTable.h"


/* Implement mc_dlog in this file */


